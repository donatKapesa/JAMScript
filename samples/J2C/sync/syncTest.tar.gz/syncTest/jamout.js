var jserver = require('jamserver')(false);
var jamlib = jserver.jamlib;
var jnode = jserver.jnode;
var Flow = jserver.Flow;
var InFlow = jserver.InFlow;
var OutFlow = jserver.OutFlow;
var http = require('http');
var cbor = require('cbor');
var qs = require('querystring');
var path = require('path');
var mime = require('mime');
var fs = require('fs');
var jcondition = new Map();
function runsynctest() {
var q = fakeRandom('testing string..');
console.log("Received the results..");
console.log(q);
}
setInterval(function () {
runsynctest();
}, 110000);
function fakeRandom(s) {
return jnode.remoteSyncExec("fakeRandom", [ s ], "true", 0);
}

var mbox = {
"functions": {
},
"signatures": {
}
}
jamlib.registerFuncs(mbox);
jamlib.run(function() { console.log("Running..."); } );
