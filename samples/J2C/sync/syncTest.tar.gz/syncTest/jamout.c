#include <unistd.h>
#include "jdata.h"
#include "command.h"
#include "jam.h"
#include <stdio.h>
jamstate_t *js;
typedef char* jcallback;
char jdata_buffer[20];
char app_id[256] = { 0 };
int fakeRandom(char* s){
printf("sync time: %f\n", getcurtime());
int n = rand() % 100;
printf("Random: %d\n", n);
return n;
}
void callfakeRandom(void *act, void *arg) {
command_t *cmd = (command_t *)arg;
activity_complete(js->atable, cmd->actid, "i", fakeRandom(cmd->args[0].val.sval));
}

int user_main() {
printf("In the main...\n");
double now = getcurtime();
printf("now: %f\n", now);
double start = now + 30.0;
while(getcurtime() < start) {

}
printf("starting: %f\n", getcurtime());
return 0;
}

void user_setup() {
activity_regcallback(js->atable, "fakeRandom", SYNC, "s", callfakeRandom);
}

void jam_run_app(void *arg) {
user_main();
}

void taskmain(int argc, char **argv) {

    if (argc > 1) {
      strncpy(app_id, argv[1], sizeof app_id - 1);
    }
    js = jam_init(1883);
    user_setup();
     
    taskcreate(jam_event_loop, js, 50000);
    taskcreate(jam_run_app, js, 50000);
  }
